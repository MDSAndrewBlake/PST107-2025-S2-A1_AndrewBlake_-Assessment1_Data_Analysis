Hi, thank you for taking the time to view (and grade) my study :)

Here is the link to my GitHub repo: https://github.com/andrewblakenz/PST107-2025-S2-A2_AndrewBlake_-Assessment2_Data_Analysis

Thank you!!